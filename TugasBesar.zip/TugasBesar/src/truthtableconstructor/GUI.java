package truthtableconstructor;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;

public class GUI {
	private TruthTableConstructor constructor;
    private ArrayList<String> expressionStrings = new ArrayList<String>();
	private javax.swing.JButton generate;
	private javax.swing.JButton delete;
	private javax.swing.JButton clear;
    private javax.swing.JLabel expression;
	private javax.swing.JPanel btnContainer;
	private javax.swing.JPanel set1Container;
	private javax.swing.JPanel set2Container;
	private javax.swing.JPanel deleteContainer;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea textArea;
    private javax.swing.JFrame mainWindow;
    private JLabel lblNewLabel;
    
	public GUI(TruthTableConstructor constructor) {
		this.constructor = constructor;
		initCompenents();
		initGenerate();
		initbtnCont();
		initset1Cont();
		initset2Cont();
		initdeleteCont();
  
	}
	
	private void initdeleteCont() {
		deleteContainer.add(new CustomButton("(", this));
		delete = new JButton("Delete");
		delete.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(!expressionStrings.isEmpty()) {
					expressionStrings.remove(expressionStrings.size()-1);
					update();
				}
			}
		});
		clear = new JButton("Clear");
		clear.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				expressionStrings = new ArrayList<>();
				update();
			}
		});
		deleteContainer.add(clear);
		deleteContainer.add(delete);
		deleteContainer.add(new CustomButton(")", this));
		deleteContainer.revalidate();
	}

	private void initset1Cont() {
		char a = 'A';
		for(int i = 0 ; i < 13 ; i++) {
			
			set1Container.add(new CustomButton(new StringBuilder().append(a).toString(),this));
			a +=1;
		}
		set1Container.revalidate();
	}
	
	private void initset2Cont() {
		char a = 'A'+13;
		for(int i = 0 ; i < 13 ; i++) {
			set2Container.add(new CustomButton(new StringBuilder().append(a).toString(),this));
			a +=1;
		}
		set2Container.revalidate();
	}
	
	private void initGenerate() {
		generate.setText("Hasil");
        generate .addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				StringBuilder st = new StringBuilder();
				String exp = expression.getText();
				if(!exp.trim().equalsIgnoreCase(" ")) {
					try {
						Map<String , Boolean> table  = constructor.construct(exp);
						List<Map.Entry<String, Boolean>> list = new LinkedList<Map.Entry<String, Boolean>>(table.entrySet());
						Collections.sort(list , new Comparator<Map.Entry<String, Boolean>>() {
							public int compare(Map.Entry<String, Boolean> o1, Map.Entry<String, Boolean> o2) {
				                return (o1.getKey()).compareTo( o2.getKey() );
				            }
						});
						ArrayList <String> operands = constructor.getOperands(exp);
						for(String x : operands)
							st.append(x);
						st.append("\n\n");
						for(Entry<String , Boolean> z : list) {
							st.append(z.getKey()+"  ");
							if(z.getValue() == false)
								st.append("F\n");
							else
								st.append("T\n");
						}
						textArea.setText(st.toString());
					} catch (Exception e1) {
						JOptionPane.showMessageDialog(mainWindow, "Salah Format Bro", "Notifikasi Salah", JOptionPane.WARNING_MESSAGE);
					}
				}
			}
		});
	}

	private void initbtnCont() {
		for(Operator x : constructor.getSupportedOperators()) {
			btnContainer.add(new CustomButton(x.getRepresentation(), this));
		}
		btnContainer.revalidate();
	}

	private void initCompenents() {
		mainWindow = new javax.swing.JFrame();
		mainWindow.setTitle("Application Generate Truth Table");
		jScrollPane1 = new javax.swing.JScrollPane();
        textArea = new javax.swing.JTextArea();
        expression = new javax.swing.JLabel();
        btnContainer = new javax.swing.JPanel();
        generate = new javax.swing.JButton();
        set1Container = new javax.swing.JPanel();
        deleteContainer = new javax.swing.JPanel();
        set2Container = new javax.swing.JPanel();

        mainWindow.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        textArea.setColumns(15);
        textArea.setRows(5);
        textArea.setFont(new Font("Arial", Font.PLAIN, 24));
        jScrollPane1.setViewportView(textArea);

        expression.setBackground(new java.awt.Color(255, 255, 255));
        expression.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        expression.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        expression.setOpaque(true);
        
        lblNewLabel = new JLabel("\u2310 = NOT");
        
        JLabel lblNewLabel_1 = new JLabel("Keterangan :");
        
        JLabel lblNewLabel_2 = new JLabel("^ = AND");
        
        JLabel lblNewLabel_3 = new JLabel("v = OR");
        
        JLabel lblNewLabel_4 = new JLabel("\u2295 = XOR");
        
        JLabel lblNewLabel_5 = new JLabel("=> : Implikasi");
        GroupLayout groupLayout = new GroupLayout(mainWindow.getContentPane());
        groupLayout.setHorizontalGroup(
        	groupLayout.createParallelGroup(Alignment.LEADING)
        		.addGroup(groupLayout.createSequentialGroup()
        			.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
        				.addGroup(groupLayout.createSequentialGroup()
        					.addContainerGap()
        					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
        						.addComponent(set1Container, GroupLayout.PREFERRED_SIZE, 547, GroupLayout.PREFERRED_SIZE)
        						.addComponent(set2Container, GroupLayout.PREFERRED_SIZE, 547, GroupLayout.PREFERRED_SIZE)
        						.addComponent(expression, GroupLayout.PREFERRED_SIZE, 547, GroupLayout.PREFERRED_SIZE)
        						.addComponent(btnContainer, GroupLayout.PREFERRED_SIZE, 547, GroupLayout.PREFERRED_SIZE)
        						.addComponent(deleteContainer, GroupLayout.PREFERRED_SIZE, 547, GroupLayout.PREFERRED_SIZE)
        						.addComponent(generate, Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 547, GroupLayout.PREFERRED_SIZE)))
        				.addGroup(groupLayout.createSequentialGroup()
        					.addGap(22)
        					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
        						.addComponent(lblNewLabel_1)
        						.addComponent(lblNewLabel))
        					.addGap(25)
        					.addComponent(lblNewLabel_2)
        					.addGap(31)
        					.addComponent(lblNewLabel_3)
        					.addGap(30)
        					.addComponent(lblNewLabel_4)
        					.addGap(30)
        					.addComponent(lblNewLabel_5)))
        			.addPreferredGap(ComponentPlacement.RELATED)
        			.addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 370, GroupLayout.PREFERRED_SIZE))
        );
        groupLayout.setVerticalGroup(
        	groupLayout.createParallelGroup(Alignment.LEADING)
        		.addGroup(groupLayout.createSequentialGroup()
        			.addGap(82)
        			.addComponent(set1Container, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        			.addGap(18)
        			.addComponent(set2Container, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        			.addPreferredGap(ComponentPlacement.UNRELATED)
        			.addComponent(expression, GroupLayout.PREFERRED_SIZE, 38, GroupLayout.PREFERRED_SIZE)
        			.addGap(18)
        			.addComponent(btnContainer, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        			.addGap(18)
        			.addComponent(deleteContainer, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        			.addGap(18)
        			.addComponent(generate, GroupLayout.PREFERRED_SIZE, 86, GroupLayout.PREFERRED_SIZE)
        			.addGap(14)
        			.addComponent(lblNewLabel_1)
        			.addPreferredGap(ComponentPlacement.UNRELATED)
        			.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(lblNewLabel)
        				.addComponent(lblNewLabel_2)
        				.addComponent(lblNewLabel_3)
        				.addComponent(lblNewLabel_4)
        				.addComponent(lblNewLabel_5))
        			.addGap(50))
        		.addGroup(groupLayout.createSequentialGroup()
        			.addGap(11)
        			.addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 561, GroupLayout.PREFERRED_SIZE))
        );
        mainWindow.getContentPane().setLayout(groupLayout);
        mainWindow.pack();
        mainWindow.setVisible(true);
	}
	
	public javax.swing.JLabel getExpression() {
		return expression;
	}
	
	public ArrayList<String> getExpressionStrings() {
		return expressionStrings;
	}
	
	public void update() {
		StringBuilder st = new StringBuilder();
		for(String x : expressionStrings) {
			st.append(x +" ");
		}
		expression.setText(st.toString());
	}
}
